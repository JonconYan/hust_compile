int f2(int a,int b)
{
    int a,b=0;
    a+b=10;
    (a+b)++;
    ++a++;
    return 12.3;
}
