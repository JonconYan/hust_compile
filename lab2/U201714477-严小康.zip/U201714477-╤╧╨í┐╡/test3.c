int f3()
{
   int a,b;
   if (a-b) continue;//continue不在循环内
   else break;//break不在循环内
   while ( a || f2(1,2)) {while(1) break;continue;}
   for(a=1;a>0 && f2(1,2)>0;a++)
 	if (a+b==0) break;
   return y;
}
