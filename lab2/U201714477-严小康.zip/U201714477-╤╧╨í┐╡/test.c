int f1()
{
    int a[3][3];
}