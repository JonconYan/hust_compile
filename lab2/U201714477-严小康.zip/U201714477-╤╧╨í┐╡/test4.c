int f5(int a)  
{
    float x[10][20],y=12.3;
    x=a[1]+f5[1];
    x[1]=x[1][y]+x[1+1][1];
    return y;
}
